#include <stdio.h>

int main() {

	char *a="Hello ";
	char *b="World!";

  printf("Hello World!");
	printf("%s World!", a);
	printf("Hello %s!", b);

  // .
  // .
  // .
  //
}
