#include <stdio.h>
main() {printf("OK\n"); return 0;}
